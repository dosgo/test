package com.dosgo.castx;

import android.app.*;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.media.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.Surface;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;

public class ScreenCastService extends Service {
    private static final int NOTIFICATION_ID = 123;
    private static final String CHANNEL_ID = "screen_cast_channel";

    // 编码参数
    private static final int FRAME_RATE = 30;
    private static final int BIT_RATE = 5_000_000;
    private static final int I_FRAME_INTERVAL = 1;

    private MediaProjection mediaProjection;
    private MediaCodec mediaCodec;
    private Surface inputSurface;
    private boolean isRunning;
    private HandlerThread encoderThread;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification());

        if (intent != null && !isRunning) {
            int resultCode = intent.getIntExtra("EXTRA_RESULT_CODE", -1);
            Intent resultData = intent.getParcelableExtra("EXTRA_RESULT_INTENT");
            if (resultCode != -1 && resultData != null) {
                startEncoding(resultCode, resultData);
                isRunning = true;
            }
        }
        return START_STICKY;
    }

    private void startEncoding(int resultCode, Intent resultData) {
        try {
            // 1. 初始化编码器
            initMediaCodec();

            // 2. 获取MediaProjection实例
            MediaProjectionManager manager =
                    (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            mediaProjection = manager.getMediaProjection(resultCode, resultData);

            // 3. 创建虚拟显示
            DisplayMetrics metrics = getResources().getDisplayMetrics();
            mediaProjection.createVirtualDisplay(
                    "ScreenCast",
                    metrics.widthPixels,
                    metrics.heightPixels,
                    metrics.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    inputSurface,
                    null,
                    null
            );

            // 4. 启动编码线程
            startEncoderThread();

        } catch (Exception e) {
            stopSelf();
        }
    }

    private void initMediaCodec() throws IOException {
        mediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
        MediaFormat format = MediaFormat.createVideoFormat(
                MediaFormat.MIMETYPE_VIDEO_AVC,
                getResources().getDisplayMetrics().widthPixels,
                getResources().getDisplayMetrics().heightPixels
        );
        format.setInteger(MediaFormat.KEY_BIT_RATE, BIT_RATE);
        format.setInteger(MediaFormat.KEY_FRAME_RATE, FRAME_RATE);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT,
                MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, I_FRAME_INTERVAL);

        mediaCodec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        inputSurface = mediaCodec.createInputSurface();
        mediaCodec.start();
    }

    private void startEncoderThread() {
        encoderThread = new HandlerThread("ScreenEncoder");
        encoderThread.start();

        new Handler(encoderThread.getLooper()).post(() -> {
            MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();
            FileOutputStream fos = null;

            try {
                fos = new FileOutputStream(
                        new File(getExternalFilesDir(null), "screen_record.h264"));

                while (isRunning) {
                    int outIndex = mediaCodec.dequeueOutputBuffer(bufferInfo, 10_000);
                    if (outIndex >= 0) {
                        ByteBuffer encodedData = mediaCodec.getOutputBuffer(outIndex);
                        writeH264Data(encodedData, bufferInfo, fos);
                        mediaCodec.releaseOutputBuffer(outIndex, false);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (fos != null) {
                    try { fos.close(); } catch (IOException e) { /* ignore */ }
                }
            }
        });
    }

    private void writeH264Data(ByteBuffer buffer, MediaCodec.BufferInfo info,
                               FileOutputStream stream) throws IOException {
        if (info.size > 0) {
            byte[] data = new byte[info.size];
            buffer.position(info.offset);
            buffer.get(data, 0, info.size);
            stream.write(data);
        }
    }

    private Notification buildNotification() {
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("屏幕录制中")
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "录屏服务",
                    NotificationManager.IMPORTANCE_LOW
            );
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        if (encoderThread != null) {
            encoderThread.quitSafely();
        }
        if (mediaCodec != null) {
            mediaCodec.stop();
            mediaCodec.release();
        }
        if (mediaProjection != null) {
            mediaProjection.stop();
        }
        stopForeground(true);
        super.onDestroy();
    }
}