package com.dosgo.castx;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE_SCREEN_CAPTURE = 1001;
    private Button btnControl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnControl = findViewById(R.id.btn_control);
        btnControl.setOnClickListener(v -> {
            if (isServiceRunning()) {
                stopService(new Intent(this, ScreenCastService.class));
                btnControl.setText("开始投屏");
                Toast.makeText(this, "投屏已停止", Toast.LENGTH_SHORT).show();
            } else {
                startScreenCapture();
            }
        });
    }

    private void startScreenCapture() {
        MediaProjectionManager manager =
                (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(
                manager.createScreenCaptureIntent(),
                REQUEST_CODE_SCREEN_CAPTURE
        );
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_SCREEN_CAPTURE && resultCode == RESULT_OK) {
            Intent serviceIntent = new Intent(this, ScreenCastService.class)
                    .putExtra("EXTRA_RESULT_CODE", resultCode)
                    .putExtra("EXTRA_RESULT_INTENT", data);

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
            btnControl.setText("停止投屏");
        }
    }

    private boolean isServiceRunning() {
        return false; // 实际实现需检查服务状态
    }
}